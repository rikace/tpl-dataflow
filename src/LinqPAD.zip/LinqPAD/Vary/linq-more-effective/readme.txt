Many of the demos for this course are LINQPad scripts.

The easiest way to use them is to install LINQPad (available at LINQPad.net), and then you can double-click the .linq files to load them. Please note that for any .linq scripts that use NuGet packages you will need a paid version of LINQPad to actually tun them.

However, you don't actually need to use LINQPad. You can simply open these .linq files in any text editor (such as notepad) and you will see the C# code snippets shown in the videos, with some information at the top of the file about what type of LINQPad query it is, and any NuGet packages or namespaces that were referenced.
